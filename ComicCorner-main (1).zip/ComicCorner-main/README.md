<h1>Team Terminator</h1>

Team leader - Saydur Rahman<br>
C233183 - Completed his homeWork<hr>

Jobair Ahmed Efaz <br>
C233195 - Completed his homeWork<hr>

Leanur Rahman <br>
C233191 - Completed his homeWork<hr>
